1. Install the mysqlnet180.msi
2. Install the iCDataManager.msi